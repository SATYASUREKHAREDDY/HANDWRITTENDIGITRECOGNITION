import yaml
import streamlit_authenticator as stauth
from pathlib import Path

USER_DATA_FILE = Path("users.yaml")

# Function to register a new user
def register_user(username, name, email, password):
    if USER_DATA_FILE.exists():
        with open(USER_DATA_FILE, "r") as file:
            users = yaml.safe_load(file) or {"credentials": {"usernames": {}}}
    else:
        users = {"credentials": {"usernames": {}}}

    if username in users["credentials"]["usernames"]:
        return False, "Username already exists. Please choose a different one."

    # Correct way to hash password
    hashed_pw = stauth.Hasher().hash(password)

    users["credentials"]["usernames"][username] = {
        "name": name,
        "email": email,
        "password": hashed_pw
    }

    with open(USER_DATA_FILE, "w") as file:
        yaml.dump(users, file)

    return True, "Registration successful!"

# Function to load users for authenticator
def load_users():
    if USER_DATA_FILE.exists():
        with open(USER_DATA_FILE, "r") as file:
            return yaml.safe_load(file)
    else:
        return {"credentials": {"usernames": {}}}
