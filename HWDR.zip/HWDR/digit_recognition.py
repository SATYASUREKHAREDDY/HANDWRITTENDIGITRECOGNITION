# digit_recognition.py

import streamlit as st
import numpy as np
from PIL import Image, ImageOps
import tensorflow as tf
from streamlit_drawable_canvas import st_canvas

model = tf.keras.models.load_model('mnist_cnn_model.keras')

def preprocess_image(image_data):
    image = Image.fromarray(image_data.astype(np.uint8))
    image = image.convert('L')
    image = image.resize((28, 28))
    if np.mean(image) > 127:
        image = ImageOps.invert(image)
    image = np.array(image, dtype=np.float32)
    image = image / 255.0
    image = image.reshape(1, 28, 28, 1)
    return image

def digit_recognition_main():
    st.set_page_config(page_title="Handwritten Digit Recognition", page_icon="🖋️", layout="wide", initial_sidebar_state="expanded")

    page = st.sidebar.radio("Navigation", ["Home", "About", "Model Info", "Tutorial", "Upload Image", "Draw Digit"])

    if page == "Home":
        st.title("Handwritten Digit Recognition")
        st.write("Welcome to the Handwritten Digit Recognition App!")
        st.write("Choose from the pages on the sidebar to upload an image, draw a digit, or learn more about the project.")

    elif page == "About":
        st.title("About")
        st.write("""This project uses a CNN to recognize handwritten digits from the MNIST dataset.""")

    elif page == "Model Info":
        st.title("Model Information")
        st.write("""Model: Conv2D, MaxPool, Flatten, Dense(128), Softmax | Accuracy: ~99%""")

    elif page == "Tutorial":
        st.title("Tutorial")
        st.write("1. Upload or Draw\n2. Wait for prediction\n3. View the result")

    elif page == "Upload Image":
        st.title("Upload Image")
        uploaded_file = st.file_uploader("Choose an image...", type=["png", "jpg", "jpeg"])
        if uploaded_file:
            image = Image.open(uploaded_file)
            st.image(image, caption="Uploaded Image", use_container_width=True)
            processed = preprocess_image(np.array(image))
            prediction = model.predict(processed)
            st.write(f"Predicted Digit: {np.argmax(prediction)}")

    elif page == "Draw Digit":
        st.title("Draw Digit")
        canvas_result = st_canvas(
            fill_color="white",
            stroke_width=5,
            stroke_color="black",
            background_color="white",
            width=280, height=280,
            drawing_mode="freedraw",
            key="canvas"
        )
        if canvas_result.image_data is not None:
            st.image(canvas_result.image_data, caption="Your Drawing", use_container_width=True)
            processed = preprocess_image(canvas_result.image_data)
            prediction = model.predict(processed)
            st.write(f"Predicted Digit: {np.argmax(prediction)}")
