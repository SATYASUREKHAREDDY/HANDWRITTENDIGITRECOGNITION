import streamlit as st
from auth import register_user  # Make sure the function is correctly imported

# Set up the page title and description
st.title("Register")
st.markdown("Create a new account by providing your details.")

# Create input fields for the user
username = st.text_input("Username")
name = st.text_input("Full Name")
email = st.text_input("Email Address")
password = st.text_input("Password", type="password")
confirm_password = st.text_input("Confirm Password", type="password")

# Handle form submission
if st.button("Register"):
    if password == confirm_password:
        # Proceed with the registration
        success, message = register_user(username, name, email, password)
        if success:
            st.success(message)
            st.info("Now you can go back to the Login page and log in.")
        else:
            st.error(message)
    else:
        st.error("Passwords do not match. Please try again.")
