import streamlit as st
import streamlit_authenticator as stauth
from auth import register_user, load_users
import numpy as np
from PIL import Image, ImageOps
import tensorflow as tf
from streamlit_drawable_canvas import st_canvas

# Set page config
st.set_page_config(page_title="Digit Recognizer", layout="wide")

# Load users
config = load_users()

# Authenticator setup
authenticator = stauth.Authenticate(
    config["credentials"],
    "digit_app", "auth", cookie_expiry_days=1
)

authenticator.login()

# Load the trained model once
model = tf.keras.models.load_model('mnist_cnn_model.keras')

# Preprocess uploaded or drawn image
def preprocess_image(image_data):
    image = Image.fromarray(image_data.astype(np.uint8))
    image = image.convert('L')
    image = image.resize((28, 28))
    if np.mean(image) > 127:
        image = ImageOps.invert(image)
    image = np.array(image, dtype=np.float32)
    image = image / 255.0
    image = image.reshape(1, 28, 28, 1)
    return image

# Main digit recognition UI
def digit_recognition_main():
    page = st.sidebar.radio("Navigation", ["Home", "About", "Model Info", "Tutorial", "Upload Image", "Draw Digit"])

    if page == "Home":
        st.title("Handwritten Digit Recognition")
        st.write("Welcome to the Handwritten Digit Recognition App!")
        st.write("Choose from the pages on the sidebar to upload an image, draw a digit, or learn more about the project.")

    elif page == "About":
        st.title("About")
        st.write("""
    This project uses a Convolutional Neural Network (CNN) to recognize handwritten digits from the MNIST dataset.
    The app allows you to either upload an image or draw a digit, and the model will predict which digit it is (0-9).
    It is built using Streamlit for the frontend, TensorFlow for the machine learning model, and Python for the backend.
    """)

    elif page == "Model Info":
        st.title("Model Information")
        st.write("""
    The CNN model used for this app was trained on the MNIST dataset, which consists of 28x28 pixel grayscale images of handwritten digits.
    The model architecture is as follows:
    - Conv2D Layer (32 filters, 3x3 kernel)
    - MaxPooling2D Layer (2x2 pool size)
    - Flatten Layer
    - Dense Layer (128 units, ReLU activation)
    - Output Layer (Softmax activation for 10 classes)
    
    The model achieved an accuracy of ~99% on the test set.
    """)

    elif page == "Tutorial":
        st.title("Tutorial")
        st.write("""
    **How to use the app:**
    1. Go to the **'Upload Image'** page to upload an image of a handwritten digit.
    2. Alternatively, go to the **'Draw Digit'** page and draw a digit on the canvas.
    3. The model will predict the digit and display the result.
    
    **Tips:**
    - For better predictions, try to keep the digits clear and centered.
    - The model works best with digits written in a similar style to the MNIST dataset.
    """)

    elif page == "Upload Image":
# File uploader in Streamlit to allow users to upload an image
        st.title("Handwritten Digit Recognition")
        st.markdown("upload an image of a handwritten digit, and the model will predict which digit it is!(0-9)")
        uploaded_file = st.file_uploader("Choose an image...", type=["png", "jpg", "jpeg"])

        if uploaded_file is not None:


    # Open the uploaded image
            image = Image.open(uploaded_file)
    
    # Display the original uploaded image
            st.image(image, caption="Uploaded Image", use_container_width=True)

    # Preprocess the image
    # Step 1: Convert to grayscale
            image = image.convert('L')  # Convert to grayscale (MNIST format is grayscale)

    # Step 2: Resize to 28x28 pixels
            image = image.resize((28, 28))

    # Step 3: Invert colors (MNIST is white digits on black background)
    # Invert only if the background is not black
            if np.mean(image) > 127:

                image = ImageOps.invert(image)

    # Step 4: Convert image to a numpy array
            image = np.array(image, dtype=np.float32)

    # Step 5: Normalize pixel values to the range [0, 1]
            image = image / 255.0

    # Step 6: Reshape image to match model input shape
            image = image.reshape(1, 28, 28, 1)

    # Display preprocessed image to verify if it’s correct
            st.image(image.reshape(28, 28), caption="Preprocessed Image", use_container_width=True, clamp=True)

    # Predict the digit
            prediction = model.predict(image)
    
    # Display the full prediction array for debugging
            st.write(f"Prediction Array: {prediction}")
    
    # Get the digit with the highest probability
            predicted_digit = np.argmax(prediction)
    
    # Display the result
            st.write(f"Predicted Digit: {predicted_digit}")


    elif page == "Draw Digit":
        st.title("Draw Digit")
        st.markdown("Draw a digit on the canvas and the model will predict which digit it is (0-9).")
    
    # Drawing pad
        canvas_result = st_canvas(
        fill_color="white", 
        stroke_width=5, 
        stroke_color="black", 
        background_color="white", 
        width=280, height=280, 
        drawing_mode="freedraw",
        key="canvas"
    )
    
        if canvas_result.image_data is not None:
            image = canvas_result.image_data
            st.image(image, caption="Your Drawing", use_container_width=True,channels="RGB")
        
        # Preprocess and predict
            preprocessed_image = preprocess_image(image)
            prediction = model.predict(preprocessed_image)
            predicted_digit = np.argmax(prediction)
        
        # Display the prediction
            st.write(f"Predicted Digit: {predicted_digit}")

# Handle authentication logic
if st.session_state["authentication_status"] is None:
    st.warning("Please enter your username and password.")
    # Show register option before login
    if st.sidebar.button("Register"):
        register_user()
    st.stop()

elif st.session_state["authentication_status"] is False:
    st.error("Username or password is incorrect.")
    # Still allow registration
    if st.sidebar.button("Register"):
        register_user()
    st.stop()

elif st.session_state["authentication_status"]:
    authenticator.logout("Logout", "sidebar")
    st.sidebar.success(f"Welcome, {st.session_state['name']} 👋")
    digit_recognition_main()
